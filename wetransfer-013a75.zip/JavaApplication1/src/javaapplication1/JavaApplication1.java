/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author oob
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FileInputStream inputStream = null;
        try {
            File file = new File("E:\\1.xlsx");
            inputStream = new FileInputStream(file);
            Workbook guru99Workbook = null;
            //Find the file extension by splitting file name in substring  and getting only extension name
            String fileExtensionName = file.getName().substring(file.getName().indexOf("."));
            //    String fileExtensionName = "";
            //Check condition if the file is xlsx file
            if (fileExtensionName.equals(".xlsx")) {

                //If it is xlsx file then create object of XSSFWorkbook class
                guru99Workbook = new XSSFWorkbook(inputStream);

            } //Check condition if the file is xls file
            else if (fileExtensionName.equals(".xls")) {

                //If it is xls file then create object of HSSFWorkbook class
//                guru99Workbook = new HSSFWorkbook(inputStream);
            }   //Read sheet inside the workbook by its name
            Sheet guru99Sheet = guru99Workbook.getSheet("Sheet1");
            //Find number of rows in excel file
            int rowCount = guru99Sheet.getLastRowNum() - guru99Sheet.getFirstRowNum();
            //Create a loop over all the rows of excel file to read it
            for (int i = 1; i < rowCount + 1; i++) {

                Row row = guru99Sheet.getRow(i);

                //Print Excel data in console
                String env = row.getCell(0).getStringCellValue();
                String cust = row.getCell(1).getNumericCellValue() + "";
                String url = "https://qatools.kabeldeutschland.de/index.php?module=ajax&action=registerCSC&env=" + env + "&accountNumber=" + cust;
                System.out.println();
                Cell cell = row.createCell(3);
                cell.setCellValue("write here");

            }
        } catch (Exception ex) {
            Logger.getLogger(JavaApplication1.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                inputStream.close();
            } catch (IOException ex) {
                Logger.getLogger(JavaApplication1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
